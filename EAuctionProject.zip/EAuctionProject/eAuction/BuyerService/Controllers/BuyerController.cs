﻿using BuyerService.Model;
using BuyerService.Processor.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuyerService.Controllers
{
    [ApiController]
    
    [Route("api/v1/Buyer")]
    public class BuyerController : ControllerBase
    {
        // GET: BuyerController
        public IBuyerProcessor _buyerProcessor;
        public BuyerController(IBuyerProcessor buyerProcessor)
        {
            this._buyerProcessor = buyerProcessor;
        }

        
        [HttpGet]
        public string Get()
        {
            return "ok";
        }

        [HttpPost]
        [Route("PlaceBid")]
        
        public int PlaceBid([FromBody] Buyer product)
        {
            return this._buyerProcessor.PlaceBid(product);
        }
        
    }
}
