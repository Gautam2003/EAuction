﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SellerService.Model;
using SellerService.Repositories.Interfaces;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System.Globalization;

namespace SellerService.Repositories
{
    /*public class SellerRepository
    {
    }*/

    public class SellerRepository : ISellerRepository
    {
        private readonly AppSetting _appSettingAccessor;
        private readonly MongoDBConfig _mongoDBConfig;

        public SellerRepository(IOptions<AppSetting> appSettingAccessor, IOptions<MongoDBConfig> mongoDBAccesssor)
        {
            _appSettingAccessor = appSettingAccessor.Value;
            _mongoDBConfig = mongoDBAccesssor.Value;
        }

        public int PlaceOrder(Seller placeOrder)
        {
            var client = new MongoClient(_appSettingAccessor.DatabaseConnectionString);
            var database = client.GetDatabase(_appSettingAccessor.DatabaseName);
            //var client = new MongoClient(_mongoDBConfig.ConnectionString);
            //var database = client.GetDatabase(_mongoDBConfig.Database);
            var products = database.GetCollection<Seller>("Product");                        
            products.InsertOne(placeOrder);
            products = database.GetCollection<Seller>("Product");
            //List<Seller> lstProducts = products.Find(x => x.productId==12345678).ToList();
            return 0;

        }

       public string DeleteOrder(int productid)
        {

            try
            {
                var filter = Builders<Seller>.Filter.Eq("productId", productid);

                var client = new MongoClient(_appSettingAccessor.DatabaseConnectionString);
                var database = client.GetDatabase(_appSettingAccessor.DatabaseName);               
                var products = database.GetCollection<Seller>("Product");
                var selectedProduct = products.Find(x => x.productId == productid).ToList().FirstOrDefault();
                               
                if (selectedProduct != null && selectedProduct.bidEndDate != null)
                {
                    //selectedProduct.bidEndDate = selectedProduct.bidEndDate.Replace("/", "-");
                    CultureInfo cultureinfo = new System.Globalization.CultureInfo("en-US");
                    DateTime dtUS = DateTime.ParseExact(selectedProduct.bidEndDate, "MM/dd/yyyy", cultureinfo);

                    DateTime currentTime = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time"));

                    if (dtUS < currentTime)
                    {
                        throw new Exception("Product is tried to be deleted after the bid end date");
                    }
                }


                //Code to be added for Biding

                var buyer = database.GetCollection<BuyerDetail>("Buyer");
                var selectedbuyer = buyer.Find(x => x.ProductId == productid).ToList().FirstOrDefault();
                //var getbuyerdetail= buyer.Find(filterbuyer).FirstOrDefault();
                if (selectedbuyer != null)
                {
                    throw new Exception(" At least one bid is placed on that product");
                }

                products.DeleteOne(filter);
                //var selectedProduct1 = products.Find(x => x.productId == productid).ToList().FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return "success";



        }

      public  GetBuyer_ProduceDetail GetAllBidsForProduct(int productid)
        {

            GetBuyer_ProduceDetail getdetail = new GetBuyer_ProduceDetail();
            var client = new MongoClient(_appSettingAccessor.DatabaseConnectionString);
            var database = client.GetDatabase(_appSettingAccessor.DatabaseName);
            var products = database.GetCollection<Seller>("Product");
            var selectedProduct = products.Find(x => x.productId == productid).ToList().FirstOrDefault();
            if (selectedProduct != null)
            {
                getdetail.bidEndDate = selectedProduct.bidEndDate;
                getdetail.category = selectedProduct.category;
                getdetail.detailedDescription = selectedProduct.detailedDescription;
                getdetail.productName = selectedProduct.productName;
                getdetail.startingPrice = selectedProduct.startingPrice;

            }
            var biddetails = database.GetCollection<BuyerDetail>("Buyer");
            if (biddetails != null)
            {
                List<BuyerDetail> lstbidDetail = biddetails.Find(x => x.ProductId == productid).ToList().OrderBy(A=>A.BidAmount).ToList();
                getdetail.GetBuyerDetail = lstbidDetail;
            }



            return getdetail;


        }

    }
}
