﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SellerService.Model
{
    public class GetBuyer_ProduceDetail
    {

        public List<BuyerDetail> GetBuyerDetail { get; set; }

        public string productName { get; set; }
        //public double BidAmount { get; set; }

        public string shortDescription { get; set; }
        public string detailedDescription { get; set; }
        public string category { get; set; }
        public double startingPrice { get; set; }
        public string bidEndDate { get; set; }

    }
}
