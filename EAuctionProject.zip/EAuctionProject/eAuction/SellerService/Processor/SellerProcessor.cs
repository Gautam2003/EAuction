﻿using SellerService.Model;
using SellerService.Processor.Interfaces;
using SellerService.Repositories;
using SellerService.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SellerService.Processor
{
    public class SellerProcessor : ISellerProcessor
    {
        public ISellerRepository _sellerRepository;
        public SellerProcessor(ISellerRepository sellerRepository)
        {
            this._sellerRepository = sellerRepository;
        }

        public int PlaceOrder(Seller product)
        {
            return this._sellerRepository.PlaceOrder(product);

        }

        public string DeleteOrder(int productid)
        {
             return this._sellerRepository.DeleteOrder(productid);
        }

        public GetBuyer_ProduceDetail GetAllBidsForProduct(int productid)
        {
            return this._sellerRepository.GetAllBidsForProduct(productid);

        }



}

    }

