﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SellerService.Model;

namespace SellerService.Processor.Interfaces
{
    public interface ISellerProcessor
    {
        int PlaceOrder(Seller product);
        string DeleteOrder(int productid);

        GetBuyer_ProduceDetail GetAllBidsForProduct(int productid);
    }


}
