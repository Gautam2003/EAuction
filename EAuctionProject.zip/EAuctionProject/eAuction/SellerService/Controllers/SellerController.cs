﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SellerService.Model;
using SellerService.Processor.Interfaces;

namespace SellerService.Controllers
{
    [Route("api/v1/Seller")]
    [ApiController]
    public class SellerController : ControllerBase
    {

        public ISellerProcessor _sellerProcessor;
        public SellerController(ISellerProcessor sellerProcessor)
        {
            this._sellerProcessor = sellerProcessor;
        }

        [HttpGet]
        public string Get()
        {
            return "ok";
        }

        [HttpPost]
        [Route("PlaceOrder")]
        public IActionResult PostPlaceOrder([FromBody] Seller product)
        {
            try
            {
                product.productId = DateTime.Now.Millisecond;// to have unique product id 
                return Ok(this._sellerProcessor.PlaceOrder(product));
            }
            catch (Exception ex)
            {
                return BadRequest(new InvalidOperationException(ex.Message));
            }
        }

        [HttpDelete("{productid}")]
        public IActionResult Delete(int productid)
        {
            try
            {
                //return this._sellerProcessor.DeleteOrder(productid);
                return Ok(this._sellerProcessor.DeleteOrder(productid));
            }
            catch (Exception ex)
            {
                return BadRequest(new InvalidOperationException(ex.Message));
            }
        }

        

        [HttpPost]
        [Route("GetAllBidsForProduct")]
        public IActionResult GetAllBidsForProduct(int productid)
        {
            try
            {
                //return this._sellerProcessor.GetAllBidsForProduct(productid);
                return Ok(this._sellerProcessor.GetAllBidsForProduct(productid));
            }
            catch (Exception ex)
            {
                return BadRequest(new InvalidOperationException(ex.Message));
            }

        }




    }
}
